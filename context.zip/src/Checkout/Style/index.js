import styled from 'styled-components';

const CheckoutStyle = styled.div`
    margin: 20px 0px;
`;

export default CheckoutStyle;