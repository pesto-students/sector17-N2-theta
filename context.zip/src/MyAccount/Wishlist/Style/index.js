import styled from 'styled-components';

const WishlistStyle = styled.div`
  width: 100%;
`;

export default WishlistStyle;