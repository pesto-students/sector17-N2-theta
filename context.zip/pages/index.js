import Home from '../src/Home';
export default Home;