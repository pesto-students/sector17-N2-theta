import { Fragment } from "react"
import Orders from "src/Orders"

const Orders = () => {
    return <Fragment>
        <Orders />
    </Fragment>
}
export default Orders;