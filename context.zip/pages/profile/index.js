import { Fragment } from "react"
import MyAccount from "src/MyAccount"

const Profile = () => {
    return <Fragment>
        <MyAccount />
    </Fragment>
}
export default Profile;