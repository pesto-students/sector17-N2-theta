import { firebase } from "@/data";
import "firebase/auth";

const fbAuth = firebase.auth;

export default fbAuth;
