import { getSlidersEntity } from "./helpers";
export const getSlider = async () => {
  return await getSlidersEntity();
};
