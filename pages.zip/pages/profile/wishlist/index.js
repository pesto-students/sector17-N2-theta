import Wishlist from "../../../src/MyAccount/Wishlist";
export default Wishlist;