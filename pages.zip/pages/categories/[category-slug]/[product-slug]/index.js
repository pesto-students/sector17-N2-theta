import Product from "../../../../src/Product";
export default Product;