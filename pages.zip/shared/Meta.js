import Head from 'next/head';

const Meta = () => {
  return <Head>
    <title>Sector17</title>
  </Head>
}

export default Meta;