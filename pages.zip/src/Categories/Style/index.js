import styled from "styled-components";

const CategoriesStyle = styled.div`
  .categories__inner {
    max-width: 1260px;
    margin: 0 auto;
  }
`;

export default CategoriesStyle;