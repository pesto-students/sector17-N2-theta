import styled from "styled-components";

const MyAccountStyle = styled.div`
  margin-top: 30px;
  .dashboard{
    flex: 3;
  }
`;

export default MyAccountStyle;
