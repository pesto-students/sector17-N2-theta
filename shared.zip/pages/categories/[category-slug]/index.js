import Catalog from "../../../src/Catalog";
export default Catalog;