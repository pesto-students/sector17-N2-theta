import Categories from "../../src/Categories";
export default Categories;
