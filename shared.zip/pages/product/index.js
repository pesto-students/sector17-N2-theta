import { Fragment } from "react"

const Product = () => {
    return <Fragment>
        <h1>Product Page</h1>
    </Fragment>
}
export default Product;