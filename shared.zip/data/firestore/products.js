import { getSingleEntity, paginationQuery } from "./helpers";

export const getProducts = async ({
  offset = 0,
  limit = 10,
  orderBy = "sku",
  category = "",
  sku = [],
  filter = [],
  price = [],
}) => {
  const where = [];
  console.log(filter);
  /** Categories */
  if (!!category) {
    where.push(["category", "==", category]);
  }

  /** SKUs */
  if (Array.isArray(sku) && sku.length > 0) {
    where.push(["sku", "in", sku]);
  }
  /** Filter With Manufacturer */
  if (Array.isArray(filter) && filter.length > 0) {
    where.push(["manufacturer", "in", filter]);
  }
  /** Filter With Price */
  if (Array.isArray(price) && price.length > 0) {
    where.push(["price", ">=", price[0]]);
    where.push(["price", "<=", price[1]]);
    orderBy = "price";
  }
  return await paginationQuery("products", orderBy, offset, limit, where);
};

export const getCategories = async (offset = 0, limit = 10, orderBy = "id") => {
  return await paginationQuery("categories", orderBy, offset, limit);
};

export const getSingleProduct = async (id) => {
  return await getSingleEntity("products", id);
};
